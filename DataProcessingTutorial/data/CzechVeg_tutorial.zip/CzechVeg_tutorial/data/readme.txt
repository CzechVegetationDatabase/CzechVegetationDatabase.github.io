Prepared by Irena Axmanová 2025-11-07

Data from Czech forests sampled along productivity gradient.
This dataset was used in the paper Axmanová et al. 2012,
focused on relationship of herb-layer species richness and different environmental factors
https://onlinelibrary.wiley.com/doi/10.1111/j.1466-8238.2011.00707.x

In the paper, there were additional datasets used, 
here is only the Czech subset.


Acknowledgements
Help with sampling these plots
David Zelený, Woody- Ching-Feng Li, Marie Vymazalová

Supervisor of the PhD
Milan Chytrý