library(foreign)   #for reading dbf files
library(tidyverse) #for data handling, pipes and visualisation
library(readxl)    #for data import directly from Excel
library(janitor)   #for unified, easy-to-handle format of variable names
